package com.bezkoder.springjwt.repository;


import com.bezkoder.springjwt.models.EMail;
import freemarker.template.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.Map;

@Service
public class MailSenderSpring {
    @Autowired
    JavaMailSender javaMailSender;
    @Qualifier("freemarkerConfiguration")
    @Autowired
    Configuration fmConfiguration;

    public void sendEmail(EMail mail) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(mail.getTo());
        msg.setFrom(mail.getFrom());
        msg.setSubject(mail.getSubject());
        msg.setText(mail.getContent());
        javaMailSender.send(msg);
    }

    public void sendEmailWithAttachment(EMail mail) throws MessagingException, IOException {
        MimeMessage msg = javaMailSender.createMimeMessage();
        // true = multipart message
        MimeMessageHelper helper = new MimeMessageHelper(msg, true);

        helper.setTo(mail.getTo());
        helper.setFrom(mail.getFrom());
        helper.setSubject(mail.getSubject());
        helper.setText(mail.getContent());

        // hard coded a file path
        // FileSystemResource file = new FileSystemResource(new    File("path/img.png"));
        // helper.addAttachment("Google Photo",file);
        helper.addAttachment("Google Photo", new ClassPathResource("img.png"));
        javaMailSender.send(msg);
    }

    @Value("classpath:/images/001-diet.png")
    private Resource dietpng;

    @Value("classpath:/images/my.jpeg")
    private Resource resourceFile;

    @Value("classpath:/images/002-play-button.png")
    private Resource  playbuttonpng;
    @Value("classpath:/images/003-recipe-book.png")
    private Resource recipebookpng;
    @Value("classpath:/images/bg_1.jpg")
    private Resource bg_1jpg;
    @Value("classpath:/images/bg_2.jpg")
    private Resource bg_2;
    @Value("classpath:/images/bg_3.jpg")
    private Resource bg_3;
    @Value("classpath:/images/bg_4.jpg")
    private Resource bg_4;
    @Value("classpath:/images/bg_5.jpg")
    private Resource bg_5;
    @Value("classpath:/images/bg_6.jpg")
    private Resource bg_6;
    @Value("classpath:/images/blog-1.jpg")
    private Resource blog1;
    @Value("classpath:/images/blog-2.jpg")
    private Resource blog2;
    @Value("classpath:/images/menu-1.jpg")
    private Resource menu1jpg;
    @Value("classpath:/images/menu-2.jpg")
    private Resource menu2jpg;
    @Value("classpath:/images/person_1.jpg")
    private Resource person_1jpg;
    @Value("classpath:/images/person_2.jpg")
    private Resource person_2jpg;


    public void sendEmailWithTemplate(EMail mail,String message) {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {

            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");


            mimeMessageHelper.setSubject(mail.getSubject());
            mimeMessageHelper.setFrom(mail.getFrom());
            mimeMessageHelper.setTo(mail.getTo());
            mail.setContent(geContentFromTemplate(mail.getModel(),message));
            mimeMessageHelper.setText(mail.getContent(), true);
            mimeMessageHelper.addInline("attachment.jpeg", resourceFile);
            mimeMessageHelper.addInline("001-diet.png", dietpng);
            mimeMessageHelper.addInline("002-play-button.png", playbuttonpng);
            mimeMessageHelper.addInline("003-recipe-book.png", recipebookpng);
            mimeMessageHelper.addInline("bg_1.jpg", bg_1jpg);
            mimeMessageHelper.addInline("bg_2.jpg", bg_2);
            mimeMessageHelper.addInline("bg_3.jpg", bg_3);
            mimeMessageHelper.addInline("bg_4.jpg", bg_4);
            mimeMessageHelper.addInline("bg_5.jpg", bg_5);
            mimeMessageHelper.addInline("bg_6.jpg", bg_6);
            mimeMessageHelper.addInline("blog-1.jpg", blog1);
            mimeMessageHelper.addInline("blog-2.jpg", blog2);
            mimeMessageHelper.addInline("menu-1.jpg", menu1jpg);
            mimeMessageHelper.addInline("menu-2.jpg", menu2jpg);
            mimeMessageHelper.addInline("person_1.jpg", person_1jpg);
            mimeMessageHelper.addInline("person_2.jpg", person_2jpg);

            javaMailSender.send(mimeMessageHelper.getMimeMessage());
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public String geContentFromTemplate(Map<String, Object> model,String message) {
        StringBuffer content = new StringBuffer();

        try {
            content.append(FreeMarkerTemplateUtils.processTemplateIntoString(fmConfiguration.getTemplate(message), model));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content.toString();
    }
}

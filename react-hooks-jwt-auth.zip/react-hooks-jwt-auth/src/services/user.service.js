import axios from "axios";
import authHeader from "./auth-header";

const API_URL = "http://localhost:8080/api/test/";

const getPublicContent = () => {
  return axios.get(API_URL + "all");
};

const getUserBoard = () => {
  return axios.get(API_URL + "user", { headers: authHeader() });
};

const getModeratorBoard = () => {
  return axios.get(API_URL + "mod", { headers: authHeader() });
};

const getAdminBoard = () => {
  return axios.get(API_URL + "admin", { headers: authHeader() });
};
const upload = (file, onUploadProgress) => {
  let formData = new FormData();
  formData.append("file", file);
  let ctype = {
    "Content-Type": "multipart/form-data",
  };
  return axios.post(API_URL + "upload",formData, { headers: authHeader(),ctype,onUploadProgress });

};
//to get info of already stored files
const getFiles = () => {
  return axios.get(API_URL + "files", { headers: authHeader() });
};

const sendEmail = (emailTemplate) =>{
  return axios.get(API_URL,"sendmail")
}

const saveCampaign = campaign => {
  debugger;
  return axios.post(API_URL + "saveCampaign",{"campaign_type":campaign.campaign_type,"campaign_message":campaign.campaign_message}, { headers: authHeader() });
};

const saveTargetAudience = campaign => {
  debugger;
  return axios.post(API_URL + "saveTargetAudience",{"age":campaign.age,"gender":campaign.gender,"location":campaign.state}, { headers: authHeader() });
};
const saveCampaignDate = campaign => {
  debugger;
  return axios.post(API_URL + "saveCampaignDate",{"time":campaign}, { headers: authHeader() });
};

const sendCampaign = () => {
  debugger;
  return axios.get(API_URL + "sendCampaign", { headers: authHeader() });
};

const getItems = () => {
  debugger;
  return axios.get(API_URL + "items", { headers: authHeader() });
};
const increaseItemCount = item => {
  debugger;
  return axios.get(API_URL + item, { headers: authHeader() });
};

const UserService = {
  getPublicContent,
  getUserBoard,
  getModeratorBoard,
  getAdminBoard,
  upload,
  getFiles,
  sendEmail,
  saveCampaign,
  saveTargetAudience,
  saveCampaignDate,
  sendCampaign,
  getItems,
  increaseItemCount
};

export default UserService;

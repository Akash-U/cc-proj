import React, { useState, useEffect } from "react";

import UserService from "../services/user.service";
import EventBus from "../common/EventBus";
import {Link, useNavigate} from "react-router-dom";

const TargetAudience = () => {
    let navigate = useNavigate();

    const initialTargetAudienceState = {
        age: ""
    }
    const [selectedState, setSelectedState] = useState("texas");
    const [selectedGender, setSelectedGender] = useState("men");
    const [age, setAge] = useState(initialTargetAudienceState);

    const sendTargetAudience = () =>{
        console.log(selectedState);
        console.log(selectedGender);
        console.log(age);
        debugger;
        var data = {
            "age":age.age,
            "gender":selectedGender,
            "state":selectedState
        }
        UserService.saveTargetAudience(data)
            .then(response => {
                alert("Saved ");
                console.log(response.data);
            })
            .catch(e => {
                alert("error "+e);
                console.log(e);
            });

        navigate("/scheduler");

    }

    const handleInputChange = event => {

        const { name, value } = event.target;
        setAge({ ...age, [name]: value });
    };

    return (
        <div className="container">
            <header className="jumbotron">

                <div className="form-group">
                    <label htmlFor="title">Age</label>
                    <input
                        type="text"
                        className="form-control"
                        id="title"
                        required
                        value={age.age}
                        onChange={handleInputChange}
                        name="age"
                    />
                    <br/>
                    <label htmlFor="title">State</label>

                    <select onChange={(e)=>setSelectedState(e.target.value)}>
                        <option  value="">Select State</option>

                        <option  value="texas">Texas</option>
                        <option  value="newyork">New york</option>

                    </select>
                    <br/>
                    <label htmlFor="title">Gender</label>

                    <select onChange={(e)=>setSelectedGender(e.target.value)}>
                        <option  value="">Select Gender</option>
                        <option  value="men">Men</option>
                        <option  value="women">Women</option>
                        <option  value="kids">Kids</option>
                    </select>

                </div>
                <button onClick={sendTargetAudience} className="btn btn-success">
                    Save
                </button>

                {/*<button  className="btn btn-success">*/}
                {/*    <Link to="/scheduler" color="white">Next</Link>*/}
                {/*</button>*/}

            </header>
        </div>
    );

};
export default TargetAudience;

import React, {useEffect, useState} from 'react';
import DateTimePicker from 'react-datetime-picker';
import UserService from "../services/user.service";
import { PieChart } from 'react-minimal-pie-chart';
import Scheduler from "./Scheduler";

const Charts = () => {

    const [pastaCount, setPastaCount] = useState(0);
    const [potatoCount, setPotatoCount] = useState(0);
    const [fruitsCount, setFruitsCount] = useState(0);
    const [openCount, setOpenCount] = useState(0);

    useEffect(() => {
        UserService.getItems().
        then(response => {
             setFruitsCount(response.data[0].count);
             setPotatoCount(response.data[1].count);
             setPastaCount(response.data[2].count);
             setOpenCount(response.data[3].count)
            console.log(response.data);
        })
            .catch(e => {
                alert("error "+e);
                console.log(e);
            });
    }, []);


    return (
        <div className="container">
            <header className="jumbotron">
                <h1>Analytics</h1>
                <br/>
                <h2>Percentage of links opened</h2>
                <br/>
                <div id="chart-pie"><PieChart
            data={[
                { title: 'Pasta, Sauce Milk', value: pastaCount, color: '#e37f27' },
                { title: 'Sweetened Fruits', value: potatoCount, color: '#C13C37' },
                { title: 'Grilled tofu with potatoes', value: fruitsCount, color: '#6A2135' },
            ]}
            label={({ dataEntry }) => Math.round(dataEntry.percentage) + '%'}
        />;</div>
                <br/>
                <h2>Number of times email was opened</h2>


                        <h1>{openCount}</h1>

            </header>
        </div>
    );
}

export default Charts;

import React, { useState } from 'react';
import DateTimePicker from 'react-datetime-picker';
import UserService from "../services/user.service";
import { PieChart } from 'react-minimal-pie-chart';

const Scheduler = () => {

    const [value, onChange] = useState(new Date());
    const [showPicker, setShowPicker] = useState(undefined);
    const sendCampaign = () => {
        UserService.sendCampaign().
        then(response => {
            alert("Sent ");
            console.log(response.data);
        })
            .catch(e => {
                alert("error "+e);
                console.log(e);
            });
    }

    const scheduleCampaign = () => {
      console.log(value);
        debugger;
        UserService.saveCampaignDate(value)
            .then(response => {
                alert("Saved ");
                console.log(response.data);
            })
            .catch(e => {
                alert("error "+e);
                console.log(e);
            });

    }

    const displayPicker = (value) => {
      if(value==='schedule'){
          setShowPicker(value);
      }else {
          onChange(new Date());
          setShowPicker(undefined)
      }
    }
    return (
        <div className="container">
            <header className="jumbotron">
                <h2>Schedule Campaign</h2>
                <div className="form-group">
                    <select onChange={(e)=>displayPicker(e.target.value)}>
                        <option  value="">Select Data and time</option>
                        <option  value="sendnow">Send Now</option>
                        <option  value="schedule">Schedule</option>

                    </select>
                    <br/>
                    {showPicker && (<DateTimePicker onChange={onChange} value={value} />)}
                </div>

                {/*<button onClick={scheduleCampaign} className="btn btn-success">*/}
                {/*    Schedule*/}
                {/*</button>*/}
                <button onClick={sendCampaign} className="btn btn-success">
                    Send Campaign
                </button>


            </header>
        </div>
    );
};

export default Scheduler;

import React, { useState, useEffect } from "react";

import UserService from "../services/user.service";
import EventBus from "../common/EventBus";
import {Link, useNavigate} from "react-router-dom";

const Email = () => {
    let navigate = useNavigate();

    const initialSMS = {
        smsText: ""
    }
    const [selectedEmailTemplate, setSelectedEmailTemplate] = useState("email.flth");
    const [showEmailList, setShowEmailList] = useState(undefined);
    const [smsText, setSmsText] = useState(initialSMS);
    const [showSmsText, setShowSmsText] = useState(undefined);
    const [campaignType, setCampaignType] = useState(undefined);
    const [campaignMessage, setCampaignMessage] = useState(initialSMS);
    const [showEmailPic1, setShowEmailPic1] = useState(undefined);
    const [showEmailPic2, setShowEmailPic2] = useState(undefined);

    const handleInputChange = event => {
        const { name, value } = event.target;
         setSmsText({ ...smsText, [name]: value });
        setCampaignMessage(smsText.smsText);
    };


    const saveCampaign = () =>{
        //id	Campaign_type	campaign_message	age	location 	gender 	time
    //  if(selectedEmailTemplate!==""){
    //     setCampaignMessage(selectedEmailTemplate);
    // }
        console.log("selectedEmailTemplate "+selectedEmailTemplate);
        console.log("smsText "+smsText.smsText);

        console.log("campaignType "+campaignType);

        console.log("campaignMessage "+campaignMessage);
        debugger;
        var data = {
            "campaign_type":campaignType,
            "campaign_message":campaignMessage
        }
        UserService.saveCampaign(data)
            .then(response => {
                 console.log(response.data);
                 alert("Saved ");
             })
            .catch(e => {
                alert("error "+e);

                console.log(e);
            });

        navigate("/targetaudience");


    }

    const showEmailPicAndSelect = (value) => {
        setCampaignMessage(value);

        if(value==='email_template_1.flth'){
            setShowEmailPic1(value);
            setShowEmailPic2(undefined);

        }
        else{
            setShowEmailPic2(value);
            setShowEmailPic1(undefined);

        }

    }

    const showCampaignBasedOnSelection = (value) => {

      if(value==='email'){
          setCampaignType(value)
          setShowEmailList(value);
          setShowSmsText(undefined)
      }else {
          setCampaignType(value)
          setShowSmsText(value);
          setShowEmailList(undefined)
          setShowEmailPic1(undefined);
          setShowEmailPic2(undefined);
      }
    }

    return (
        <div className="container">
            <header className="jumbotron">

                <div className="form-group">
                    <h2>Type of Campaign</h2>
                     <select onChange={(e)=>showCampaignBasedOnSelection(e.target.value)}>
                        <option  value="">Select Type Of Campaign</option>
                        <option  value="email">Send Email Campaign</option>
                        <option  value="sms">Send SMS Campaign</option>

                    </select>
                    <br/>
                    <br/>

                    {showEmailList&& <h2>Email Template</h2>}
                    {showEmailList && (<select onChange={(e)=>showEmailPicAndSelect(e.target.value)}>

                        <option  value="">Select Email Template</option>
                       <option  value="email_template_1.flth">email_template_1.flth</option>
                        <option  value="email_template_2.flth">email_template_2.flth</option>

                    </select>)}
                    <br/>
                    {showEmailPic1 && <div style={{ margin: '100px' }}>
                         <img src="https://iili.io/HnzGe1t.md.png" alt="react logo" style={{ width: '600px', }}/>
                    </div>}
                    {showEmailPic2 && <div style={{ margin: '100px' }}>
                        <img src="https://iili.io/HnICX1I.md.png" alt="react logo" style={{ width: '600px', }}/>
                    </div>}

                    <br/>
                    {showSmsText && (<textarea id="w3review" name="w3review" rows="4" cols="50" value={smsText.smsText}
                              onChange={handleInputChange}
                              name="smsText"></textarea>)}

                </div>
                <button  onClick={saveCampaign} className="btn btn-success">
                    Save
                </button>

                {/*<button id="emailnext" className="btn btn-success">*/}
                {/*    <Link to="/targetaudience" color="white">Next</Link>*/}
                {/*</button>*/}

            </header>
        </div>
    );

};
export default Email;

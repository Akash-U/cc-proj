import React, { useState, useEffect } from "react";

import UserService from "../services/user.service";
import EventBus from "../common/EventBus";
import {Link, useNavigate} from "react-router-dom";

const Upload = () => {
    //upload files
    let navigate = useNavigate();

    const [selectedFiles, setSelectedFiles] = useState(undefined);
    const [currentFile, setCurrentFile] = useState(undefined);
    const [progress, setProgress] = useState(0);
    const [message, setMessage] = useState("");
    const [fileInfos, setFileInfos] = useState([]);
    //upload files
    const selectFile = (event) => {
        setSelectedFiles(event.target.files);
    };

    const upload = () => {
        debugger;
        let currentFile = selectedFiles[0];

        setProgress(0);
        setCurrentFile(currentFile);

        UserService.upload(currentFile, (event) => {
            setProgress(Math.round((100 * event.loaded) / event.total));
        })
            .then((response) => {
                setMessage(response.data.message);
                //return UserService.getFiles();
            })
            .then((files) => {
                //setFileInfos(files.data);
            })
            .catch(() => {
                setProgress(0);
                setMessage("Could not upload the file!");
                setCurrentFile(undefined);
            });

        setSelectedFiles(undefined);
        setTimeout(() => {  navigate("/emaillist"); }, 5000);



    };



    return (
        <div className="container">
            <header className="jumbotron">

                <div className="form-group">

                    {/*file upload starts*/}
                    <div>
                        {currentFile && (
                            <div className="progress">
                                <div
                                    className="progress-bar progress-bar-info progress-bar-striped"
                                    role="progressbar"
                                    aria-valuenow={progress}
                                    aria-valuemin="0"
                                    aria-valuemax="100"
                                    style={{ width: progress + "%" }}
                                >
                                    {progress}%
                                </div>
                            </div>
                        )}

                        <label className="btn btn-default">
                            <input type="file" onChange={selectFile} />
                        </label>

                        <div className="alert alert-light" role="alert">
                            {message}
                        </div>

                        {/*<div className="card">*/}
                        {/*    <div className="card-header">List of Files</div>*/}
                        {/*    <ul className="list-group list-group-flush">*/}
                        {/*        {fileInfos &&*/}
                        {/*        fileInfos.map((file, index) => (*/}
                        {/*            <li className="list-group-item" key={index}>*/}
                        {/*                <a href={file.url}>{file.name}</a>*/}
                        {/*            </li>*/}
                        {/*        ))}*/}
                        {/*    </ul>*/}
                        {/*</div>*/}
                    </div>
                    {/*file upload ends*/}

                </div>
                <button  onClick={upload} className="btn btn-success">
                    Submit
                </button>


            {/*    <button  className="btn btn-success">*/}
            {/*    <Link to="/emaillist" color="white">Next</Link>*/}

            {/*</button>*/}
                {/*Post message display*/}

                {/*<ul className="list-group">*/}
                {/*    {posts &&*/}
                {/*    posts.map((cnt, index) => (*/}
                {/*        <li*/}
                {/*            key={index}*/}
                {/*        >*/}
                {/*            {cnt.postMessage}*/}
                {/*        </li>*/}
                {/*    ))}*/}
                {/*</ul>*/}
            </header>
        </div>
    );
};

export default Upload;

